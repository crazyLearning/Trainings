/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./WordCounterControl/index.ts":
/*!*************************************!*\
  !*** ./WordCounterControl/index.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.WordCounterControl = void 0;\nvar WordCounterControl = /** @class */function () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function WordCounterControl() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n  WordCounterControl.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n    this.context = context;\n    this.container = container;\n    this.notifyOutputChanged = notifyOutputChanged;\n    this.inputText = document.createElement(\"textarea\");\n    this.container.appendChild(this.inputText);\n    this.inputText.setAttribute(\"style\", \"width:100%; border:solid 1px #FF0000;box-shadow:0px 4px 5px #FFA500\");\n    this.inputText.setAttribute(\"rows\", \"5\");\n    this.inputText.value = context.parameters.commentField.raw || \"\";\n    this.inputText.addEventListener(\"keyup\", this.onKeyUp.bind(this));\n    this.remainingCount = context.parameters.wordLimit.raw || 0;\n    this.labelText = document.createElement(\"label\");\n    this.container.appendChild(this.labelText);\n    this.labelText.innerHTML = \"maximum limit is \" + context.parameters.wordLimit.raw + \" Remaining : \" + this.remainingCount || 0;\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n  WordCounterControl.prototype.updateView = function (context) {\n    // Add code to update control view\n    this.remainingCount = (context.parameters.wordLimit.raw || 0) - this.inputText.value.length;\n    this.labelText.innerHTML = \"maximum limit is \" + context.parameters.wordLimit.raw + \" Remaining : \" + this.remainingCount || 0;\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  WordCounterControl.prototype.getOutputs = function () {\n    return {\n      commentField: this.inputText.value\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  WordCounterControl.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  WordCounterControl.prototype.onKeyUp = function () {\n    // Add code to cleanup control if necessary\n    this.remainingCount = (this.context.parameters.wordLimit.raw || 0) - this.inputText.value.length;\n    this.labelText.innerHTML = \"maximum limit is \" + this.context.parameters.wordLimit.raw + \" Remaining : \" + this.remainingCount || 0;\n    if (this.remainingCount == 0) {\n      this.inputText.setAttribute(\"maxlength\", \"500\");\n    }\n    this.notifyOutputChanged();\n  };\n  return WordCounterControl;\n}();\nexports.WordCounterControl = WordCounterControl;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./WordCounterControl/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./WordCounterControl/index.ts"](0, __webpack_exports__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('WordCounterPCF.WordCounterControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.WordCounterControl);
} else {
	var WordCounterPCF = WordCounterPCF || {};
	WordCounterPCF.WordCounterControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.WordCounterControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}