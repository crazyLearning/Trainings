﻿param($installPath, $toolsPath, $package, $project)

$DTE.ItemOperations.Navigate("http://dynamicsvalue.com/get-started/nuget-install-2011?version=1.58.1")

